{-# LANGUAGE TypeOperators #-}

module HW0.T1
  ( type (<->) (..)
  , assocEither
  , assocPair
  , distrib
  , flipIso
  , runIso
  ) where

-- | Contains a function and its inverse.
data a <-> b = Iso (a -> b) (b -> a)

-- | Flip functions.
flipIso :: (a <-> b) -> (b <-> a)
flipIso (Iso f g) = Iso g f

-- | Return first function.
runIso :: (a <-> b) -> (a -> b)
runIso (Iso f _) = f

-- | An analogue of the law of distributivity.
distrib :: Either a (b, c) -> (Either a b, Either a c)
distrib (Left a)       = (Left a, Left a)
distrib (Right (b, c)) = (Right b, Right c)

-- | Analog of the law of associativity for pair.
assocPair :: (a, (b, c)) <-> ((a, b), c)
assocPair = Iso (\(a, (b, c)) -> ((a, b), c)) (\((a, b), c) -> (a, (b, c)))

-- | Analog of the law of associativity for Either.
assocEither :: Either a (Either b c) <-> Either (Either a b) c
assocEither = Iso assocLeftEither assocRightEither

assocLeftEither :: Either a (Either b c) -> Either (Either a b) c
assocLeftEither (Left a)          = Left (Left a)
assocLeftEither (Right (Left b))  = Left (Right b)
assocLeftEither (Right (Right c)) = Right c

assocRightEither :: Either (Either a b) c -> Either a (Either b c)
assocRightEither (Left (Left a))  = Left a
assocRightEither (Left (Right b)) = Right (Left b)
assocRightEither (Right c)        = Right (Right c)
