module HW0.T2
  ( Not
  , doubleNeg
  , reduceTripleNeg
  ) where

import Data.Void (Void)

-- | The representation of not.
type Not a = a -> Void

-- | In propositional logic, double negation is the theorem
-- that states that "If a statement is true, then it is
-- not the case that the statement is not true.".
doubleNeg :: a -> Not (Not a)
doubleNeg x f = f x

-- | The law of removing triple negation.
reduceTripleNeg :: Not (Not (Not a)) -> Not a
reduceTripleNeg f x = f (doubleNeg x)
