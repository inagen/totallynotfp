module HW0.T3
  ( compose
  , contract
  , i
  , k
  , permute
  , s 
  ) where

-- | S is a substitution operator. It takes three arguments
-- and then returns the first argument applied to the third,
-- which is then applied to the result of the second argument
-- applied to the third.
s :: (a -> b -> c) -> (a -> b) -> (a -> c)
s f g x = f x (g x)

-- | K, when applied to any argument x, yields a one-argument
-- constant function Kx, which, when applied to any argument, returns x.
k :: a -> b -> a
k x _ = x

-- | I returns its argument.
i :: a -> a
i = s k k

-- | Analog of the W combinator.
-- B x y z is the composition of the arguments x and y applied to the argument z.
compose :: (b -> c) -> (a -> b) -> (a -> c)
compose = s (k s) k

-- | Analog of the B combinator.
-- W x y duplicates the argument y.
contract :: (a -> a -> b) -> (a -> b)
contract = s s (s k)

-- | Analog of the C combinator.
-- C x y z swaps the arguments y and z.
permute :: (a -> b -> c) -> (b -> a -> c)
permute = s (s (k compose) s) (k k)
