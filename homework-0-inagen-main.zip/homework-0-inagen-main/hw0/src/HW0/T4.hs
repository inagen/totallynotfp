module HW0.T4
  ( fac
  , fib
  , map'
  , repeat'
  ) where

import Data.Function (fix)
import GHC.Natural (Natural)

-- | Behaves like Data.List.repeat
repeat' :: a -> [a]
repeat' x = fix (x:)

-- | Behaves like Data.List.map
map' :: (a -> b) -> [a] -> [b]
map' = fix $ \g f list -> case list of
                          []   -> []
                          x : xs -> f x : g f xs

-- | Computes the n-th Fibonacci number
fib :: Natural -> Natural
fib = fix (\f a b n -> if n == 0
                       then a
                       else f b (a + b) (n - 1)) 0 1

-- | Computes the factorial
fac :: Natural -> Natural
fac = fix (\f n -> if n == 0
                   then 1
                   else n * f (n - 1))
