module HW0.T5
  ( Nat
  , nFromNatural
  , nmult
  , nplus
  , ns
  , nToNum
  , nz
  ) where

import GHC.Natural (Natural)

-- | Analog of the Church numeral.
type Nat a = (a -> a) -> a -> a

-- | Representations of zero in Church encoding.
nz :: Nat a
nz = nFromNatural 0

-- | Representations of "succ" in Church encoding.
ns :: Nat a -> Nat a
ns n f x = n f (f x)

-- | Representations of (+) in Church encoding.
nplus :: Nat a -> Nat a -> Nat a
nplus m n f x = n f (m f x)

-- | Representations of (*) in Church encoding.
nmult :: Nat a -> Nat a -> Nat a
nmult n m f = n (m f)

-- | Converting a natural number to Church numeral.
nFromNatural :: Natural -> Nat a
nFromNatural 0 = \_ x -> x
nFromNatural n = \f x -> nFromNatural (n - 1) f (f x)

-- | Converting a Church numeral to natural number.
nToNum :: Num a => Nat a -> a
nToNum n = n (+ 1) 0
