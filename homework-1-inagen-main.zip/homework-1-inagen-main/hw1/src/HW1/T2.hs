module HW1.T2
  ( N (..),
    nplus,
    nmult,
    nsub,
    ncmp,
    nFromNatural,
    nToNum,
    nEven,
    nOdd,
    ndiv,
    nmod,
  )
where

import Data.Maybe as Maybe
import GHC.Natural (Natural)

data N = Z | S N deriving (Show)

nplus :: N -> N -> N
nplus a Z = a
nplus Z b = b
nplus a (S b) = nplus (S a) b

nmult :: N -> N -> N
nmult _ Z = Z
nmult Z _ = Z
nmult (S Z) b = b
nmult a (S Z) = a
nmult a (S b) = nplus a (nmult a b)

nsub :: N -> N -> Maybe N
nsub Z Z = Just Z
nsub Z _ = Nothing
nsub a Z = Just a
nsub (S a) (S b) = nsub a b

ncmp :: N -> N -> Ordering
ncmp Z Z = EQ
ncmp Z a = LT
ncmp a Z = GT
ncmp (S a) (S b) = ncmp a b

nFromNatural :: Natural -> N
nFromNatural 0 = Z
nFromNatural x = S (nFromNatural (x - 1))

nToNum :: Num a => N -> a
nToNum Z = 0
nToNum (S x) = (nToNum x) + 1

nEven :: N -> Bool
nEven Z = True
nEven (S n) = not (nEven n)

nOdd :: N -> Bool
nOdd n = not (nEven n)

ndiv :: N -> N -> N
ndiv _ Z = error "Division by zero"
ndiv Z _ = Z
ndiv a b
  | ncmp a b == LT = Z
  | otherwise = S (ndiv (fromJust (nsub a b)) b)

nmod :: N -> N -> N
nmod _ Z = error "Division by zero"
nmod Z _ = Z
nmod a b = fromJust (nsub a (nmult b (ndiv a b)))