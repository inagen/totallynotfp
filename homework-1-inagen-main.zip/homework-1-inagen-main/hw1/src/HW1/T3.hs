module HW1.T3
  ( Tree (..),
    tsize,
    tdepth,
    tmember,
    tinsert,
    tFromList,
  )
where

import Data.List as List

data Tree a = Leaf | Branch Int (Tree a) a (Tree a) deriving (Show)

tsize :: Tree a -> Int
tsize Leaf = 0
tsize (Branch x _ _ _) = x

tdepth :: Tree a -> Int
tdepth Leaf = 0
tdepth (Branch _ l _ r) = (max (tdepth l) (tdepth r)) + 1

tmember :: Ord a => a -> Tree a -> Bool
tmember _ Leaf = False
tmember x (Branch _ l v r)
  | x == v = True
  | x < v = tmember x l
  | otherwise = tmember x r

mkBranch :: Tree a -> a -> Tree a -> Tree a
mkBranch trl val trr = Branch ((tsize trl) + (tsize trr) + 1) trl val trr

tinsert :: Ord a => a -> Tree a -> Tree a
tinsert x Leaf = mkBranch Leaf x Leaf
tinsert x (Branch sz tl val tr)
  | x < val = mkBranch (tinsert x tl) val tr
  | x == val = (Branch sz tl val tr)
  | otherwise = mkBranch tl val (tinsert x tr)

tFromList :: Ord a => [a] -> Tree a
tFromList list = foldr tinsert Leaf list
