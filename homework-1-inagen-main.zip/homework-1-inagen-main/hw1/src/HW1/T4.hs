module HW1.T4
  ( tfoldr,
    treeToList,
  )
where

import HW1.T3 (Tree (..), tFromList)

tfoldr :: (a -> b -> b) -> b -> Tree a -> b
tfoldr _ init Leaf = init
tfoldr f init (Branch _ tl val tr) = tfoldr f (f val (tfoldr f init tr)) tl

treeToList :: Tree a -> [a]
treeToList = tfoldr (:) []