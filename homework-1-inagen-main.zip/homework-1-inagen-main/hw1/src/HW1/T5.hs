module HW1.T5
  ( splitOn,
    joinWith,
  )
where

import Data.List.NonEmpty as NonEmpty

splitOn :: Eq a => a -> [a] -> NonEmpty [a]
splitOn sep = foldr f ([] :| [])
  where
    f delim list@(head :| tail)
      | sep /= delim = (delim : head) :| tail
      | otherwise = cons [] list

joinWith :: a -> NonEmpty [a] -> [a]
joinWith delim list = foldl1 (\first second -> first ++ [delim] ++ second) list