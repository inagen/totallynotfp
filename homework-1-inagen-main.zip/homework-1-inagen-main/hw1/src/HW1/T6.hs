module HW1.T6
  ( mcat,
    epart,
  )
where

import Data.Maybe

mcat :: Monoid a => [Maybe a] -> a
mcat list = foldl f mempty list
  where
    f res x = res <> (fromMaybe mempty x)

epart :: (Monoid a, Monoid b) => [Either a b] -> (a, b)
epart list = foldl f (mempty, mempty) list
  where
    f (resl, resr) x = either fl fr x
      where
        fl xl = (resl <> xl, resr)
        fr xr = (resl, resr <> xr)