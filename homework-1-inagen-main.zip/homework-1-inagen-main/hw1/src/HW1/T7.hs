module HW1.T7
  ( ListPlus (..),
    Inclusive (..),
    DotString (..),
    Fun (..),
  )
where

-- ListPlus
data ListPlus a = a :+ ListPlus a | Last a

infixr 5 :+

instance Semigroup (ListPlus a) where
  (<>) (Last x) y = x :+ y
  (<>) (x :+ y) z = x :+ (y <> z)

-- Inclusive
data Inclusive a b = This a | That b | Both a b deriving (Show)

instance (Semigroup a, Semigroup b) => Semigroup (Inclusive a b) where
  (<>) (This x) (This y) = This (x <> y)
  (<>) (That x) (That y) = That (x <> y)
  (<>) (This x) (That y) = Both x y
  (<>) (That x) (This y) = Both y x
  (<>) (This x) (Both y z) = Both (x <> y) z
  (<>) (Both x y) (This z) = Both (x <> z) y
  (<>) (That x) (Both y z) = Both y (x <> z)
  (<>) (Both x y) (That z) = Both x (y <> z)
  (<>) (Both x y) (Both z w) = Both (x <> z) (y <> w)

-- DotString
newtype DotString = DS String deriving (Show)

instance Monoid DotString where
  mempty = DS ""

instance Semigroup DotString where
  (<>) (DS "") y = y
  (<>) x (DS "") = x
  (<>) (DS x) (DS y) = DS (x ++ "." ++ y)

-- Fun
newtype Fun a = F (a -> a)

instance Monoid (Fun a) where
  mempty = (F id)

instance Semigroup (Fun a) where
  (<>) (F f) (F g) = F (f . g)
