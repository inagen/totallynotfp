module Lib
       ( plusTwo
       ) where

plusTwo :: [Int] -> [Int]
plusTwo = map (+2)
