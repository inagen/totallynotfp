module Main where


main :: IO ()
main = print "hello"
