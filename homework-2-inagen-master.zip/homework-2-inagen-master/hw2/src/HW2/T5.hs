module HW2.T5
  ( EvaluationError (..)
  , ExceptState (..)
  , eval
  , joinExceptState
  , mapExceptState
  , modifyExceptState
  , throwExceptState
  , wrapExceptState
  ) where

import Control.Monad
import HW2.T1 (Annotated (..), Except (..), mapAnnotated, mapExcept)
import HW2.T4 (Expr (..), Prim (..))

data ExceptState e s a = ES { runES :: s -> Except e (Annotated s a) }

mapExceptState :: (a -> b) -> ExceptState e s a -> ExceptState e s b
mapExceptState fun es = ES (\x -> case runES es x of
                                    (Success (esVal :# def)) -> Success (fun esVal :# def)
                                    (Error err)              -> Error err)

wrapExceptState :: a -> ExceptState e s a
wrapExceptState a = ES (\x -> Success (a :# x))

joinExceptState :: ExceptState e s (ExceptState e s a) -> ExceptState e s a
joinExceptState es = ES (\x -> case runES es x of
                                 (Success (esVal :# def)) -> runES esVal def
                                 (Error err)              -> Error err)

modifyExceptState :: (s -> s) -> ExceptState e s ()
modifyExceptState fun = ES (\x -> Success (() :# fun x))

throwExceptState :: e -> ExceptState e s a
throwExceptState err = ES (\x -> Error err)

instance Functor (ExceptState e s) where
  fmap = mapExceptState

instance Applicative (ExceptState e s) where
  pure = wrapExceptState
  p <*> q = Control.Monad.ap p q

instance Monad (ExceptState e s) where
  m >>= f = joinExceptState (fmap f m)

data EvaluationError = DivideByZero

binaryOperation :: (Double -> Double -> Double) -> Expr -> Expr -> (Double -> Double -> Prim Double) -> ExceptState EvaluationError [Prim Double] Double
binaryOperation op l r toPrim = do
  evalL <- eval l
  evalR <- eval r
  modifyExceptState (toPrim evalL evalR :)
  return $ op evalL evalR

unaryOperation :: (Double -> Double) -> Expr -> (Double -> Prim Double) -> ExceptState EvaluationError [Prim Double] Double
unaryOperation op a toPrim = do
  evalA <- eval a
  modifyExceptState (toPrim evalA :)
  return $ op evalA

eval :: Expr -> ExceptState EvaluationError [Prim Double] Double
eval (Val a) = pure a
eval (Op (Add a b)) = binaryOperation (+) a b Add
eval (Op (Sub a b)) = binaryOperation (-) a b Sub
eval (Op (Mul a b)) = binaryOperation (*) a b Mul
eval (Op (Abs a)) = unaryOperation abs a Abs
eval (Op (Sgn a)) = unaryOperation signum a Sgn
eval (Op (Div l r)) = do
  evalL <- eval l
  evalR <- eval r
  if evalR == 0
  then throwExceptState DivideByZero
  else modifyExceptState (Div evalL evalR :)
  return $ evalL / evalR
