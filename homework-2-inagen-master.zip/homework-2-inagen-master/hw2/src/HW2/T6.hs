{-# LANGUAGE BlockArguments             #-}
{-# LANGUAGE DerivingStrategies         #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}

module HW2.T6
  ( ParseError (..)
  , Parser (..)
  , pChar
  , pEof
  , pPredicate
  , pCharacter
  , pString
  , pSpace
  , pSpaces
  , parseE
  , parseE'
  , parseT
  , parseT'
  , parseF
  , parseDouble
  , parseError
  , parseExpr
  , runP
  ) where

import           Control.Applicative
import           Control.Monad
import           Data.Char
import           GHC.Natural
import           Data.Scientific     (scientific, toRealFloat)
import           HW2.T1              (Annotated ((:#)), Except (Error, Success))
import           HW2.T4              (Expr (Op, Val),
                                      Prim (Abs, Add, Div, Mul, Sgn, Sub))
import           HW2.T5              (ExceptState (ES, runES))

newtype ParseError = ErrorAtPos Natural

newtype Parser a = P (ExceptState ParseError (Natural, String) a)
  deriving newtype (Functor, Applicative, Monad)

runP :: Parser a -> String -> Except ParseError a
runP (P p) s = case runES p (0,  s) of
                 (Error a)            ->  Error a
                 (Success (a :# def)) ->  Success a

pChar :: Parser Char
pChar = P $ ES \(pos, s) ->
  case s of
    []     -> Error (ErrorAtPos pos)
    (c:cs) -> Success (c :# (pos + 1, cs))

parseError :: Parser a
parseError = P $ ES (\x -> Error $ ErrorAtPos 0)

instance Alternative Parser where
  empty = parseError
  (<|>) (P a) (P b) = P $ ES $ \(pos, str) ->
    let run = runES a (pos,  str)
        res = case run of
          (Error e)   -> runES b (pos,  str)
          (Success s) -> run
    in res

instance MonadPlus Parser   -- No methods.

pEof :: Parser ()
pEof = P $ ES \(pos, s) -> case s of
                             [] -> Success (() :# (pos, s))
                             _  -> Error (ErrorAtPos pos)


pPredicate :: (Char -> Bool) -> Parser Char
pPredicate predicate = P $ ES \(pos, s) ->
  case s of
    []     -> Error (ErrorAtPos pos)
    (c:cs) -> if predicate c then Success (c :# (pos + 1, cs)) else Error (ErrorAtPos pos)

pCharacter :: Char -> Parser Char
pCharacter c = pPredicate (c ==)

pString :: String -> Parser String
pString [] = return []
pString (c:cs) = do
  c' <- pCharacter c
  cs' <- pString cs
  return (c':cs')

pSpace :: Parser Char
pSpace = pPredicate isSpace

pSpaces :: Parser String
pSpaces = many pSpace

{-

The contex-free grammar of arithmetic expressions:

E = E + T
E = E - T
E = T
T = T * F
T = T / F
T = F
F = 'Sgn' F
F = 'Abs' F
F = '(' E ')'
F = <double>

LL1

E = T E'
E' = + T E'
E' = - T E'
E' = EPSILON
T = F T'
T' = * F T'
T' = / F T'
T' = EPSILON
F = 'Sgn' F
F = 'Abs' F
F = '(' E ')'
F = <double>

-}

parseE :: Parser Expr
parseE = do
  t <- parseT
  pSpaces
  parseE' t

parseE' :: Expr -> Parser Expr
parseE' t = (do
    pCharacter '+'
    pSpaces
    tt <- parseT
    pSpaces
    parseE' $ Op $ Add t tt
  ) <|> (do
    pCharacter '-'
    pSpaces
    tt <- parseT
    pSpaces
    parseE' $ Op $ Sub t tt
  ) <|> return t

parseT :: Parser Expr
parseT = do
  t <- parseF
  pSpaces
  parseT' t

parseT' :: Expr -> Parser Expr
parseT' t = (do
    pCharacter '*'
    pSpaces
    tt <- parseF
    pSpaces
    parseT' $ Op $ Mul t tt
  ) <|> (do
    pCharacter '/'
    pSpaces
    tt <- parseF
    pSpaces
    parseT' $ Op $ Div t tt
  ) <|> return t

parseF :: Parser Expr
parseF = (do
    pString "abs"
    pSpaces
    Op . Abs <$> parseF
  ) <|> (do
    pString "sgn"
    pSpaces
    Op . Sgn <$> parseF
  ) <|> (do
    pCharacter '('
    pSpaces
    e <- parseE
    pSpaces
    pCharacter ')'
    return e
  ) <|> (Val <$> parseDouble)

parseDouble :: Parser Double
parseDouble = do
  wholePart <- some (pPredicate isDigit)
  decimalPart' <- parseDecimalPart
  let decimalPart = stripRight '0' decimalPart'
  return $ toRealFloat $ scientific (toInteger wholePart * (10 ^ length decimalPart) + toInteger decimalPart) $ negate $ length decimalPart

  where
    parseDecimalPart :: Parser String
    parseDecimalPart = (do
        pCharacter '.'
        some (pPredicate isDigit)
      ) <|> return ""

    toInteger :: String -> Integer
    toInteger = go (0 :: Integer)
      where
        go :: Integer -> String -> Integer
        go acc []           = acc
        go acc (digit:rest) = go (acc * 10 + asciiToDigit digit) rest

    stripRight c = reverse . dropWhile (== c) . reverse

    asciiToDigit :: Char -> Integer
    asciiToDigit c = fromIntegral (ord c - 48)

parseExpr :: String -> Except ParseError Expr
parseExpr = runP (pSpaces *> parseE <* pSpaces <* pEof)
