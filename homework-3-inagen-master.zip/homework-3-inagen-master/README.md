# Build and testing

- Build - ```cabal build```
- Testing - ```cabal test```
- Interactive console - ```cabal run hi``` 