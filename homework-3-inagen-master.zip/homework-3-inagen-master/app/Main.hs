{-# LANGUAGE ScopedTypeVariables #-}

module Main where

import           Control.Monad.Catch
import           Control.Monad.IO.Class
import           Control.Monad.Trans.Class
import qualified Data.Set                      as S
import           Prettyprinter
import           Prettyprinter.Render.Terminal
import           System.Console.Haskeline

import           HW3.Action
import           HW3.Base
import           HW3.Evaluator
import           HW3.Parser
import           HW3.Pretty

defaultPermissions :: S.Set HiPermission
defaultPermissions = S.fromList [AllowRead, AllowWrite, AllowTime]

main :: IO ()
main = runHIO (runInputT defaultSettings loop) defaultPermissions
  where
    loop :: InputT HIO ()
    loop = do
      minput <- getInputLine "hi> "
      case minput of
        Nothing -> return ()
        Just input -> do
          if null input
          then outputStrLn ""
          else (do
              case parse input of
                Left peb -> outputStrLn $ show peb
                Right hexpr ->
                  eval hexpr >>= \case
                    Left herror  -> outputStrLn $ show herror
                    Right hvalue -> do
                      lift . liftIO . putDoc $ prettyValue hvalue <> line
              outputStrLn ""
            ) `catches`
              [ Handler $ \(e :: HiInternalIOException) ->
                case e of
                  PathDoesNotExist fp -> outputStrLn $ "Path '" <> fp <> "' does not exist\n"
                  FileDoesNotExist fp -> outputStrLn $ "File '" <> fp <> "' does not exist\n"
                  DirectoryDoesNotExist fp -> outputStrLn $ "Directory '" <> fp <> "' does not exist\n"
              , Handler $ \(PermissionRequired hp :: PermissionException) ->
                case hp of
                  AllowRead  -> outputStrLn "Reading permission denied\n"
                  AllowWrite -> outputStrLn "Writing permission denied\n"
                  AllowTime  -> outputStrLn "Time access permission denied\n"
              ]
          loop
