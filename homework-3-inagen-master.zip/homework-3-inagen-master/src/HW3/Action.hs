{-# LANGUAGE RecordWildCards #-}

module HW3.Action where

import qualified Control.Exception      as E
import           Control.Monad
import           Control.Monad.Catch    as C
import           Control.Monad.IO.Class
import           Data.Bool
import qualified Data.ByteString        as BS
import qualified Data.ByteString.Lazy   as BSL
import qualified Data.List              as L
import           Data.Maybe
import qualified Data.Sequence          as Seq
import qualified Data.Set               as S
import qualified Data.Text              as T
import           Data.Text.Encoding
import           System.Directory

import           HW3.Base

-- | Runnable action permissions.
data HiPermission
  = AllowRead
  | AllowWrite
  | AllowTime
  deriving (Eq, Ord, Show)

-- | An exception type indicating a failure to meet an expected permission from a runnable action.
data PermissionException
  = PermissionRequired HiPermission
  deriving (Eq, Show)

instance E.Exception PermissionException

-- | Data type, encapsulating an @IO@ action that may throw either a filepath exception or
-- a permission exception. A filepath exception is thrown within the @IO@ environment, and the
-- permission exception is thrown in the @HiMonad HIO@ instance: if an runnable action requires
-- a certain permission, and that permision is not present in the set, an exception is thrown.
newtype HIO a = HIO
  { runHIO :: S.Set HiPermission -> IO a
  }

instance Functor HIO where
  fmap f HIO{..} = HIO $ fmap f . runHIO

instance Applicative HIO where
  pure = HIO . const . return
  HIO rf <*> HIO ra = HIO $ \permSet -> rf permSet <*> ra permSet

instance Monad HIO where
  HIO r >>= f = HIO $ \permSet -> do
    a <- r permSet
    runHIO (f a) permSet

instance HiMonad HIO where
  runAction a = HIO $ \permSet -> do
    let perm = if
          | needsReadingPermission a -> Just AllowRead
          | needsWritingPermission a -> Just AllowWrite
          | needsTimePermission a -> Just AllowTime
          | otherwise -> Nothing
    unless (isNothing perm || fromJust perm `S.member` permSet) .
      E.throwIO . PermissionRequired $ fromJust perm
    runAction a

instance MonadIO HIO where
  liftIO action = HIO $ const action

instance MonadThrow HIO where
  throwM = liftIO . E.throwIO

instance MonadCatch HIO where
  catch haction f = HIO $ \permSet -> runHIO haction permSet `C.catch` (\e -> runHIO (f e) permSet)

instance MonadMask HIO where
  mask f = f $ \h -> HIO $ \permSet -> E.mask $ \ioToio -> ioToio $ runHIO h permSet
  uninterruptibleMask f = f $ \h ->
    HIO $ \permSet -> E.uninterruptibleMask $ \ioToio -> ioToio $ runHIO h permSet
  generalBracket hio exit action = HIO $ \permSet -> do
    generalBracket
      (runHIO hio permSet)
      (\a ec -> runHIO (exit a ec) permSet)
      (\a -> runHIO (action a) permSet)
