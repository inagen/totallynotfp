{-# LANGUAGE DeriveGeneric   #-}
{-# LANGUAGE RecordWildCards #-}

module HW3.Base where

import           Codec.Serialise
import qualified Control.Exception    as E
import qualified Data.ByteString      as BS
import qualified Data.ByteString.Lazy as BSL
import qualified Data.Map.Strict      as MS
import qualified Data.Sequence        as Seq
import qualified Data.Set             as S
import qualified Data.Text            as T
import           Data.Text.Encoding
import           Data.Time
import           GHC.Generics
import           System.Directory
import           System.Random

-- | Function identifiers.
data HiFun
  = HiFunDiv
  | HiFunMul
  | HiFunAdd
  | HiFunSub
  | HiFunNot
  | HiFunAnd
  | HiFunOr
  | HiFunLessThan
  | HiFunGreaterThan
  | HiFunEquals
  | HiFunNotLessThan
  | HiFunNotGreaterThan
  | HiFunNotEquals
  | HiFunIf
  | HiFunLength
  | HiFunToUpper
  | HiFunToLower
  | HiFunReverse
  | HiFunTrim
  | HiFunList
  | HiFunRange
  | HiFunFold
  | HiFunPackBytes
  | HiFunUnpackBytes
  | HiFunEncodeUtf8
  | HiFunDecodeUtf8
  | HiFunZip
  | HiFunUnzip
  | HiFunSerialise
  | HiFunDeserialise
  | HiFunRead
  | HiFunWrite
  | HiFunMkDir
  | HiFunChDir
  | HiFunParseTime
  | HiFunRand
  | HiFunEcho
  | HiFunCount
  | HiFunKeys
  | HiFunValues
  | HiFunInvert
  deriving (Eq, Ord, Generic)

instance Show HiFun where
  show HiFunDiv            = "div"
  show HiFunMul            = "mul"
  show HiFunAdd            = "add"
  show HiFunSub            = "sub"
  show HiFunNot            = "not"
  show HiFunAnd            = "and"
  show HiFunOr             = "or"
  show HiFunLessThan       = "less-than"
  show HiFunGreaterThan    = "greater-than"
  show HiFunEquals         = "equals"
  show HiFunNotLessThan    = "not-less-than"
  show HiFunNotGreaterThan = "not-greater-than"
  show HiFunNotEquals      = "not-equals"
  show HiFunIf             = "if"
  show HiFunLength         = "length"
  show HiFunToUpper        = "to-upper"
  show HiFunToLower        = "to-lower"
  show HiFunReverse        = "reverse"
  show HiFunTrim           = "trim"
  show HiFunList           = "list"
  show HiFunRange          = "range"
  show HiFunFold           = "fold"
  show HiFunPackBytes      = "pack-bytes"
  show HiFunUnpackBytes    = "unpack-bytes"
  show HiFunEncodeUtf8     = "encode-utf8"
  show HiFunDecodeUtf8     = "decode-utf8"
  show HiFunZip            = "zip"
  show HiFunUnzip          = "unzip"
  show HiFunSerialise      = "serialise"
  show HiFunDeserialise    = "deserialise"
  show HiFunRead           = "read"
  show HiFunWrite          = "write"
  show HiFunMkDir          = "mkdir"
  show HiFunChDir          = "cd"
  show HiFunParseTime      = "parse-time"
  show HiFunRand           = "rand"
  show HiFunEcho           = "echo"
  show HiFunCount          = "count"
  show HiFunKeys           = "keys"
  show HiFunValues         = "values"
  show HiFunInvert         = "invert"

instance Serialise HiFun

-- | This predicate returns @True@ when and only only when the supplied function is either an
-- if-statement or a conjunction / disjunction, indicating the laziness on some of its arguments.
lazyEval :: HiFun -> Bool
lazyEval = \case
  HiFunAnd -> True
  HiFunOr -> True
  HiFunIf -> True
  _ -> True

-- | Values.
data HiValue
  = HiValueNull
  | HiValueBool Bool
  | HiValueNumber Rational
  | HiValueString T.Text
  | HiValueTime UTCTime
  | HiValueFunction HiFun
  | HiValueAction HiAction
  | HiValueDict (MS.Map HiValue HiValue)
  | HiValueList (Seq.Seq HiValue)
  | HiValueBytes BS.ByteString
  deriving (Eq, Ord, Show, Generic)

instance Serialise HiValue

isNumber :: HiValue -> Bool
isNumber = \case HiValueNumber _ -> True; _ -> False

isFunction :: HiValue -> Bool
isFunction = \case HiValueFunction _ -> True; _ -> False

isBool :: HiValue -> Bool
isBool = \case HiValueBool _ -> True; _ -> False

isNull :: HiValue -> Bool
isNull = \case HiValueNull -> True; _ -> False

isString :: HiValue -> Bool
isString = \case HiValueString _ -> True; _ -> False

isList :: HiValue -> Bool
isList = \case HiValueList _ -> True; _ -> False

isBytes :: HiValue -> Bool
isBytes = \case HiValueBytes _ -> True; _ -> False

isAction :: HiValue -> Bool
isAction = \case HiValueAction _ -> True; _ -> False

isTime :: HiValue -> Bool
isTime = \case HiValueTime _ -> True; _ -> False

isDict :: HiValue -> Bool
isDict = \case HiValueDict _ -> True; _ -> False

-- | Expressions, such as function calls, wrapped values, runnables or dictionary accumulators.
data HiExpr
  = HiExprValue HiValue
  | HiExprApply HiExpr [HiExpr]
  | HiExprRun HiExpr
  | HiExprDict [(HiExpr, HiExpr)]
  deriving (Eq, Show)

-- | Evaluation errors.
data HiError
  = HiErrorInvalidArgument
  | HiErrorInvalidFunction
  | HiErrorArityMismatch
  | HiErrorDivideByZero
  deriving (Eq, Show)

-- | Runnable actions, interacting with an environment instantiating the @HiMonad@ typeclass.
data HiAction
  = HiActionRead  FilePath
  | HiActionWrite FilePath BS.ByteString
  | HiActionMkDir FilePath
  | HiActionChDir FilePath
  | HiActionCwd
  | HiActionNow
  | HiActionRand Int Int
  | HiActionEcho T.Text
  deriving (Eq, Ord, Show, Generic)

instance Serialise HiAction

-- | Check if the runnable action needs reading permission.
needsReadingPermission :: HiAction -> Bool
needsReadingPermission = \case
  HiActionRead _ -> True
  HiActionChDir _ -> True
  HiActionCwd -> True
  _ -> False

-- | Check if the runnable action needs writing permission.
needsWritingPermission :: HiAction -> Bool
needsWritingPermission = \case
  HiActionWrite _ _ -> True
  HiActionMkDir _ -> True
  HiActionEcho _ -> True
  _ -> False

-- | Check if the runnable action needs time access permission.
needsTimePermission :: HiAction -> Bool
needsTimePermission = \case
  HiActionNow -> True
  _ -> False

-- | Typeclass of all such Monads that produce a HiValue depending on the supplied runnable action.
class Monad m => HiMonad m where
  runAction :: HiAction -> m HiValue
  runAction _ = return HiValueNull

-- | A type of filepath errors; can be thrown either in the @IO@ or the @HIO@ environments.
data HiInternalIOException
  = PathDoesNotExist FilePath
  | FileDoesNotExist FilePath
  | DirectoryDoesNotExist FilePath
  deriving (Eq, Show)

instance E.Exception HiInternalIOException

instance HiMonad IO where
  runAction (HiActionRead fp) = do
    isDir <- doesDirectoryExist fp
    isFile <- doesFileExist fp
    if
      | isDir -> HiValueList . Seq.fromList . (HiValueString . T.pack <$>) <$>
        listDirectory fp
      | isFile -> do
        bytes <- BS.readFile fp
        case decodeUtf8' bytes of
          Left _  -> return $ HiValueBytes bytes
          Right t -> return $ HiValueString t
      | otherwise -> E.throwIO $ PathDoesNotExist fp
  runAction (HiActionWrite fp bs) = BSL.writeFile fp (BSL.fromStrict bs) >> return HiValueNull
  runAction (HiActionMkDir fp) = createDirectory fp >> return HiValueNull
  runAction (HiActionChDir fp) = do
    isDir <- doesDirectoryExist fp
    if isDir
    then setCurrentDirectory fp >> return HiValueNull
    else E.throwIO $ DirectoryDoesNotExist fp
  runAction HiActionCwd = HiValueString . T.pack <$> getCurrentDirectory
  runAction HiActionNow = HiValueTime <$> getCurrentTime
  runAction (HiActionRand a b) = HiValueNumber . fromIntegral <$> randomRIO (a, b)
  runAction (HiActionEcho t) = putStrLn (T.unpack t) >> return HiValueNull
