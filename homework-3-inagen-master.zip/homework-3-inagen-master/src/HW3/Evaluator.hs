module HW3.Evaluator where

import           Codec.Compression.Zlib
import           Codec.Serialise
import           Control.Monad
import           Control.Monad.Trans.Class
import           Control.Monad.Trans.Except
import           Data.Bool
import qualified Data.ByteString            as BS
import qualified Data.ByteString.Lazy       as BSL
import           Data.Foldable
import qualified Data.List                  as L
import qualified Data.Map.Strict            as MS
import           Data.Ratio
import           Data.Semigroup
import qualified Data.Sequence              as Seq
import qualified Data.Text                  as T
import           Data.Text.Encoding
import           Data.Time
import           System.FilePath
import qualified Text.Read                  as R

import           HW3.Base

-- | Evaluate a @HiExpr@ object. During the evaluation the respective errors may be thrown.
eval :: HiMonad m => HiExpr -> m (Either HiError HiValue)
eval hexpr = runExceptT $ case hexpr of
  HiExprValue v -> pure v
  HiExprApply he hes -> ExceptT (eval he) >>= \case
    HiValueFunction func -> analyzeFunction func hes
    HiValueString t      -> analyzeListLike (T.unpack t) hes
      (HiValueString . T.singleton)
      (HiValueString . T.pack)
    HiValueList l        -> analyzeListLike (toList l) hes
      id
      (HiValueList . Seq.fromList)
    HiValueBytes y -> analyzeListLike (BS.unpack y) hes
      (HiValueNumber . fromIntegral)
      (HiValueBytes . BS.pack)
    HiValueDict m -> analyzeDict m hes
    _                    -> throwE HiErrorInvalidFunction
  HiExprRun he -> ExceptT (eval he) >>= \case
    HiValueAction ha -> lift $ runAction ha
    v -> throwE HiErrorInvalidArgument
  HiExprDict kvs -> HiValueDict . MS.fromList <$> traverse (\(he1, he2) -> do
      hv1 <- ExceptT $ eval he1
      hv2 <- ExceptT $ eval he2
      pure (hv1, hv2)
    ) kvs
  where
    -- | Perform the dictionary lookup.
    analyzeDict :: HiMonad m => MS.Map HiValue HiValue -> [HiExpr] -> ExceptT HiError m HiValue
    analyzeDict m args'
      | length args' /= 1 = throwE HiErrorArityMismatch
      | otherwise = do
        args <- evalArgs args'
        let [a] = args
        case a `MS.lookup` m of
          Nothing -> pure HiValueNull
          Just hv -> pure hv

    analyzeListLike
      :: HiMonad m
      => [a]                       -- ^ The primary list object
      -> [HiExpr]                  -- ^ The list of arguments
      -> (a -> HiValue)            -- ^ The element accessor function
      -> ([a] -> HiValue)          -- ^ The slicing function
      -> ExceptT HiError m HiValue -- ^ The resulting HiValue that may contain a thrown error
    analyzeListLike l args' elementWrapper sliceWrapper
      | length args' `notElem` [1, 2] = throwE HiErrorArityMismatch
      | otherwise = do
        args <- evalArgs args'
        let len = length l
        if
          | length args == 1 -> do
            let [a] = args
            unless (isNumber a) $ throwE HiErrorInvalidArgument
            let [HiValueNumber r] = args
            unless (denominator r == 1) $ throwE HiErrorInvalidArgument
            let i = fromIntegral (numerator r)
            if i < 0 || i >= len
            then pure HiValueNull
            else pure . elementWrapper $ l !! i
          | null l -> pure $ sliceWrapper l
          | otherwise -> do
            let [a1, a2] = args
            unless ((isNumber a1 || isNull a1) && (isNumber a2 || isNull a2)) $
              throwE HiErrorInvalidArgument
            let r1 = if isNull a1
                     then 0
                     else let HiValueNumber r = a1 in r
            let r2 = if isNull a2
                     then fromIntegral len
                     else let HiValueNumber r = a2 in r
            unless (denominator r1 == 1 && denominator r2 == 1) $ throwE HiErrorInvalidArgument
            let start =
                  let tmp = fromIntegral (numerator r1)
                  in
                    if len < 2 || tmp >= 0
                    then tmp
                    else tmp `mod` len
            let end =
                  let tmp = fromIntegral (numerator r2)
                  in
                    if
                      | tmp == 0 -> 0
                      | tmp >= len -> len
                      | otherwise -> tmp `mod` len
            pure . sliceWrapper . take (end - start) $ drop start l

    -- | Perform function analysis & construct the @HiValue@ object by applying
    -- a predefined set of functions on the arguments, depending on the @HiFun@ constructor.
    -- Pre-evaluation of the function arguments does also depend on it.
    analyzeFunction :: HiMonad m => HiFun -> [HiExpr] -> ExceptT HiError m HiValue
    analyzeFunction func args'
      | length args' `notElem` getFunArity func = throwE HiErrorArityMismatch
      | otherwise = if lazyEval func then analyzeLazy else analyzeStrict
      where
        -- | Perform function processing with pre-evaluated arguments.
        analyzeStrict = do
          args <- evalArgs args'
          case func of
            HiFunDiv -> do
              let [a1, a2] = args
              unless (isNumber a1 && isNumber a2 || isString a1 && isString a2) $
                throwE HiErrorInvalidArgument
              if isNumber a1
              then do
                let [HiValueNumber r1, HiValueNumber r2] = args
                when (r2 == 0) $ throwE HiErrorDivideByZero
                pure . HiValueNumber $ r1 / r2
              else do
                let [HiValueString t1, HiValueString t2] = args
                pure . HiValueString . T.pack $ T.unpack t1 </> T.unpack t2
            HiFunMul -> do
              let [a1, a2] = args
              unless ((isNumber a1 || isString a1 || isList a1 || isBytes a1) && isNumber a2) $
                throwE HiErrorInvalidArgument
              let HiValueNumber r = a2
              let i = fromIntegral (numerator r)
              if
                | isNumber a1 -> do
                  let HiValueNumber r' = a1
                  pure . HiValueNumber $ r' * r
                | isString a1 -> do
                  unless (denominator r == 1 && i > 0) $ throwE HiErrorInvalidArgument
                  let HiValueString t = a1
                  pure . HiValueString $ i `stimes` t
                | isList a1 -> do
                  unless (denominator r == 1 && i > 0) $ throwE HiErrorInvalidArgument
                  let HiValueList l = a1
                  pure . HiValueList $ i `stimes` l
                | otherwise -> do
                  unless (denominator r == 1 && i > 0) $ throwE HiErrorInvalidArgument
                  let HiValueBytes y = a1
                  pure . HiValueBytes $ i `stimes` y
            HiFunAdd -> do
              let [a1, a2] = args
              unless ((isNumber a1 || isTime a1) && isNumber a2 ||
                      isString a1 && isString a2 ||
                      isList a1 && isList a2 ||
                      isBytes a1 && isBytes a2) $
                throwE HiErrorInvalidArgument
              if
                | isNumber a1 -> do
                  let [HiValueNumber r1, HiValueNumber r2] = args
                  pure . HiValueNumber $ r1 + r2
                | isTime a1 -> do
                  let [HiValueTime u, HiValueNumber r] = args
                  pure . HiValueTime $ addUTCTime (fromRational r) u
                | isString a1 -> do
                  let [HiValueString t1, HiValueString t2] = args
                  pure . HiValueString $ t1 <> t2
                | isList a1 -> do
                  let [HiValueList l1, HiValueList l2] = args
                  pure . HiValueList $ l1 Seq.>< l2
                | otherwise -> do
                  let [HiValueBytes y1, HiValueBytes y2] = args
                  pure . HiValueBytes $ y1 <> y2
            HiFunSub -> do
              let [a1, a2] = args
              unless (isNumber a1 && isNumber a2 ||
                      isTime a1 && isTime a2) $ throwE HiErrorInvalidArgument
              if isNumber a1
              then do
                let [HiValueNumber r1, HiValueNumber r2] = args
                pure . HiValueNumber $ r1 - r2
              else do
                let [HiValueTime u1, HiValueTime u2] = args
                pure . HiValueNumber . toRational . nominalDiffTimeToSeconds $ diffUTCTime u1 u2
            HiFunNot -> do
              let [a] = args
              unless (isBool a) $ throwE HiErrorInvalidArgument
              let [HiValueBool b] = args
              pure . HiValueBool $ not b
            HiFunLessThan -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 < a2
            HiFunGreaterThan -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 > a2
            HiFunEquals -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 == a2
            HiFunNotLessThan -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 >= a2
            HiFunNotGreaterThan -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 <= a2
            HiFunNotEquals -> do
              let [a1, a2] = args
              pure . HiValueBool $ a1 /= a2
            HiFunLength -> do
              let [a] = args
              unless (isString a || isList a) $ throwE HiErrorInvalidArgument
              if isString a
              then do
                let [HiValueString t] = args
                pure . HiValueNumber . fromIntegral $ T.length t
              else do
                let [HiValueList l] = args
                pure . HiValueNumber . fromIntegral $ Seq.length l
            HiFunToLower -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueString $ T.toLower t
            HiFunToUpper -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueString $ T.toUpper t
            HiFunReverse -> do
              let [a] = args
              unless (isString a || isList a) $ throwE HiErrorInvalidArgument
              if isString a
              then do
                let [HiValueString t] = args
                pure . HiValueString $ T.reverse t
              else do
                let [HiValueList l] = args
                pure . HiValueList $ Seq.reverse l
            HiFunTrim -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueString $ T.strip t
            HiFunList -> pure . HiValueList $ Seq.fromList args
            HiFunRange -> do
              let [a1, a2] = args
              unless (isNumber a1 && isNumber a2) $ throwE HiErrorInvalidArgument
              let [HiValueNumber r1, HiValueNumber r2] = args
              pure . HiValueList . Seq.fromList $ map (HiValueNumber . toRational)
                [r1 .. r2]
            HiFunFold -> do
              let [a1, a2] = args
              unless (isFunction a1 && isList a2) $ throwE HiErrorInvalidArgument
              let [HiValueFunction f, HiValueList l] = args
              if null l
              then return HiValueNull
              else ExceptT . eval $ constructNestedApplication f l
            HiFunPackBytes -> do
              let [a] = args
              unless (isList a) $ throwE HiErrorInvalidArgument
              let [HiValueList l] = args
              unless (all isNumber l) $ throwE HiErrorInvalidArgument
              let rats = map (\(HiValueNumber rat) -> rat) $ toList l
              unless (all (\r -> denominator r == 1 && r >= 0 && r < 256) rats) $
                throwE HiErrorInvalidArgument
              let w8s = map (fromIntegral . numerator) rats
              pure . HiValueBytes $ BS.pack w8s
            HiFunUnpackBytes -> do
              let [a] = args
              unless (isBytes a) $ throwE HiErrorInvalidArgument
              let [HiValueBytes y] = args
              pure . HiValueList . Seq.fromList . map (HiValueNumber . toRational . fromIntegral)
                $ BS.unpack y
            HiFunEncodeUtf8 -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueBytes $ encodeUtf8 t
            HiFunDecodeUtf8 -> do
              let [a] = args
              unless (isBytes a) $ throwE HiErrorInvalidArgument
              let [HiValueBytes y] = args
              pure $ either (const HiValueNull) HiValueString (decodeUtf8' y)
            HiFunZip -> do
              let [a] = args
              unless (isBytes a) $ throwE HiErrorInvalidArgument
              let [HiValueBytes y] = args
              pure . HiValueBytes . BSL.toStrict .
                compressWith defaultCompressParams { compressLevel = bestCompression } $
                BSL.fromStrict y
            HiFunUnzip -> do
              let [a] = args
              unless (isBytes a) $ throwE HiErrorInvalidArgument
              let [HiValueBytes y] = args
              pure . HiValueBytes . BSL.toStrict . decompress $ BSL.fromStrict y
            HiFunSerialise -> do
              let [a] = args
              pure . HiValueBytes . BSL.toStrict $ serialise a
            HiFunDeserialise -> do
              let [a] = args
              unless (isBytes a) $ throwE HiErrorInvalidArgument
              let [HiValueBytes y] = args
              pure . deserialise $ BSL.fromStrict y
            HiFunRead -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueAction $ HiActionRead (T.unpack t)
            HiFunWrite -> do
              let [a1, a2] = args
              unless (isString a1 && (isString a2 || isBytes a2)) $ throwE HiErrorInvalidArgument
              let HiValueString t1 = a1
              if isString a2
              then do
                let HiValueString t2 = a2
                pure . HiValueAction $ HiActionWrite (T.unpack t1) . encodeUtf8 $ t2
              else do
                let HiValueBytes y2 = a2
                pure . HiValueAction $ HiActionWrite (T.unpack t1) y2
            HiFunMkDir -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueAction $ HiActionMkDir (T.unpack t)
            HiFunChDir -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueAction $ HiActionChDir (T.unpack t)
            HiFunParseTime -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure $ maybe
                HiValueNull HiValueTime (R.readMaybe (T.unpack t) :: Maybe UTCTime)
            HiFunRand -> do
              let [a1, a2] = args
              unless (isNumber a1 && isNumber a2) $ throwE HiErrorInvalidArgument
              let [HiValueNumber r1, HiValueNumber r2] = args
              unless (denominator r1 == 1 && denominator r2 == 1) $
                throwE HiErrorInvalidArgument
              let num1 = numerator r1
              let num2 = numerator r2
              let minB = fromIntegral (minBound :: Int)
              let maxB = fromIntegral (maxBound :: Int)
              unless (minB <= num1 && num1 <= maxB && minB <= num2 && num2 <= maxB) $
                throwE HiErrorInvalidArgument
              pure . HiValueAction $ HiActionRand (fromIntegral num1) (fromIntegral num2)
            HiFunEcho -> do
              let [a] = args
              unless (isString a) $ throwE HiErrorInvalidArgument
              let [HiValueString t] = args
              pure . HiValueAction $ HiActionEcho t
            HiFunCount -> do
              let [a] = args
              unless (isList a || isString a || isBytes a) $
                throwE HiErrorInvalidArgument
              if
                | isString a -> do
                  let [HiValueString t] = args
                  constructDictWith (T.unpack t) $ HiValueString . T.singleton . head
                | isList a -> do
                  let [HiValueList l] = args
                  constructDictWith (toList l) head
                | otherwise -> do
                  let [HiValueBytes y] = args
                  constructDictWith (BS.unpack y) $ HiValueNumber . fromIntegral . head
            HiFunKeys -> do
              let [a] = args
              unless (isDict a) $ throwE HiErrorInvalidArgument
              let [HiValueDict m] = args
              pure . HiValueList . Seq.fromList $ MS.keys m
            HiFunValues -> do
              let [a] = args
              unless (isDict a) $ throwE HiErrorInvalidArgument
              let [HiValueDict m] = args
              pure . HiValueList . Seq.fromList $ MS.elems m
            HiFunInvert -> do
              let [a] = args
              unless (isDict a) $ throwE HiErrorInvalidArgument
              let [HiValueDict m] = args
              pure . HiValueDict . fmap (HiValueList . Seq.fromList) . L.foldl' (\acc (k, v) ->
                  if v `MS.member` acc
                  then MS.insertWith (++) v [k] acc
                  else MS.insert v [k] acc
                ) MS.empty $ MS.toList m
            _ -> analyzeLazy

        -- | Perform lazy function processing, where the arguments are only evaluated
        -- when needed.
        analyzeLazy = case func of
          HiFunAnd -> do
            let [a1', a2'] = args'
            a1 <- ExceptT $ eval a1'
            if
              | isNull a1 -> pure a1
              | isBool a1 -> do
                let HiValueBool b = a1
                if not b then pure a1 else ExceptT $ eval a2'
              | otherwise -> ExceptT $ eval a2'
          HiFunOr -> do
            let [a1', a2'] = args'
            a1 <- ExceptT $ eval a1'
            if
              | isNull a1 -> ExceptT $ eval a2'
              | isBool a1 -> do
                let HiValueBool b = a1
                if not b then ExceptT $ eval a2' else pure a1
              | otherwise -> pure a1
          HiFunIf -> do
            let [pred', t', e'] = args'
            pred <- ExceptT $ eval pred'
            unless (isBool pred) $ throwE HiErrorInvalidArgument
            let HiValueBool predicate = pred
            bool (ExceptT $ eval e') (ExceptT $ eval t') predicate
          _        -> analyzeStrict

        constructDictWith
          :: (Ord a, HiMonad m)
          => [a]                       -- ^ A list of values
          -> ([a] -> HiValue)          -- ^ A function taking the first element of the list
                                       --   and wrapping it in a @HiValue@ constructor
          -> ExceptT HiError m HiValue -- ^ The resulting dictionary
        constructDictWith l f =
          pure . HiValueDict . MS.fromList . map (\l ->
              ( f l
              , HiValueNumber . fromIntegral $ length l
              )
            ) . L.group $ L.sort l

        constructNestedApplication :: HiFun -> Seq.Seq HiValue -> HiExpr
        constructNestedApplication f s =
          let func = HiExprValue $ HiValueFunction f
          in
            foldl1 (\h1 h2 -> HiExprApply func [h1, h2]) $ fmap HiExprValue s

    -- | Return the arity(ies) of a function.
    getFunArity :: HiFun -> [Int]
    getFunArity = \case
      HiFunDiv -> [2]
      HiFunMul -> [2]
      HiFunAdd -> [2]
      HiFunSub -> [2]
      HiFunNot -> [1]
      HiFunAnd -> [2]
      HiFunOr -> [2]
      HiFunLessThan -> [2]
      HiFunGreaterThan -> [2]
      HiFunEquals -> [2]
      HiFunNotLessThan -> [2]
      HiFunNotGreaterThan -> [2]
      HiFunNotEquals -> [2]
      HiFunIf -> [3]
      HiFunLength -> [1]
      HiFunToUpper -> [1]
      HiFunToLower -> [1]
      HiFunReverse -> [1]
      HiFunTrim -> [1]
      HiFunList -> [0 ..] -- meaning the arity is variadic
      HiFunRange -> [2]
      HiFunFold -> [2]
      HiFunPackBytes -> [1]
      HiFunUnpackBytes -> [1]
      HiFunEncodeUtf8 -> [1]
      HiFunDecodeUtf8 -> [1]
      HiFunZip -> [1]
      HiFunUnzip -> [1]
      HiFunSerialise -> [1]
      HiFunDeserialise -> [1]
      HiFunRead -> [1]
      HiFunWrite -> [2]
      HiFunMkDir -> [1]
      HiFunChDir -> [1]
      HiFunParseTime -> [1]
      HiFunRand -> [2]
      HiFunEcho -> [1]
      HiFunCount -> [1]
      HiFunKeys -> [1]
      HiFunValues -> [1]
      HiFunInvert -> [1]

    -- | Perform stricte evaluation of the function arguments before processing
    -- the function itself.
    evalArgs :: HiMonad m => [HiExpr] -> ExceptT HiError m [HiValue]
    evalArgs [] = pure []
    evalArgs (a : as) = do
      a' <- ExceptT $ eval a
      (a' :) <$> evalArgs as
