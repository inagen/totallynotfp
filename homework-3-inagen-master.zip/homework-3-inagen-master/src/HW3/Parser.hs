{-# LANGUAGE TypeSynonymInstances #-}

module HW3.Parser where

import           Control.Monad.Combinators.Expr
import qualified Data.ByteString                as BS
import           Data.Functor
import           Data.Scientific
import qualified Data.Sequence                  as S
import qualified Data.Text                      as T
import           Data.Void
import           Data.Word
import           Text.Megaparsec
import           Text.Megaparsec.Char           as C
import qualified Text.Megaparsec.Char.Lexer     as L

import           Data.Char
import           HW3.Base
import           HW3.Evaluator
import           HW3.Util

-- | The type alias of the main @ParsecT@ entity.
type Parser = Parsec Void String

instance HiMonad Parser

-- | A space consumer, determining how our parser will process whitespaces, line comments &
-- block comments.
sc :: Parser ()
sc = L.space
  C.space1
  (L.skipLineComment "//")
  (L.skipBlockComment "/*" "*/")

-- | A parser that matches the given string & picks up all the trailing spaces.
symbol :: String -> Parser String
symbol = L.symbol sc

-- | A wrapper that picks up all the trailing spaces.
lexeme :: Parser a -> Parser a
lexeme = L.lexeme sc

-- | A parser that another parser between two parentheses.
parens :: Parser a -> Parser a
parens = between (symbol "(") (symbol ")")

-- | A helper function to construct a left-associative infix operator @name@ that encapsulates
-- the calculation logic of a supplied binary function @f@.
infixLeft :: String -> (HiExpr -> HiExpr -> HiExpr) -> Operator Parser HiExpr
infixLeft name f = InfixL (f <$ symbol name)

-- | A helper function to construct a non-associative infix operator @name@ that encapsulates
-- the calculation logic of a supplied binary function @f@.
infixNon :: String -> (HiExpr -> HiExpr -> HiExpr) -> Operator Parser HiExpr
infixNon name f = InfixN (f <$ symbol name)

-- | A helper function to construct a right-associative infix operator @name@ that encapsulates
-- the calculation logic of a supplied binary function @f@.
infixRight :: String -> (HiExpr -> HiExpr -> HiExpr) -> Operator Parser HiExpr
infixRight name f = InfixR (f <$ symbol name)

-- | A helper function to construct a postfix operator @name@ that encapsulates the calculation
-- logic of a supplied unary function @f@.
postfix :: String -> (HiExpr -> HiExpr) -> Operator Parser HiExpr
postfix name f = Postfix (f <$ symbol name)

-- | The Hi language table of operators.
opTable :: [[Operator Parser HiExpr]]
opTable =
  [ [ InfixL $ (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunDiv)) [h1, h2]) <$
      try (symbol "/" <* notFollowedBy (symbol "="))
    , infixLeft "*" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunMul)) [h1, h2])
    ]
  , [ infixLeft "+" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunAdd)) [h1, h2])
    , infixLeft "-" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunSub)) [h1, h2])
    ]
  , [ infixNon "<=" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunNotGreaterThan)) [h1, h2])
    , infixNon ">=" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunNotLessThan)) [h1, h2])
    , infixNon ">" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunGreaterThan)) [h1, h2])
    , infixNon "<" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunLessThan)) [h1, h2])
    , infixNon "==" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunEquals)) [h1, h2])
    , infixNon "/=" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunNotEquals)) [h1, h2])
    ]
  , [ infixRight "&&" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunAnd)) [h1, h2])
    ]
  , [ infixRight "||" (\h1 h2 -> HiExprApply (HiExprValue (HiValueFunction HiFunOr)) [h1, h2])
    ]
  ]

-- | Parsing a string. Any character can be processed in between the two string encapsulating
-- literals.
stringLiteral :: Parser String
stringLiteral = single '\"' *> manyTill L.charLiteral (single '\"')

-- Parsing a function identifier.
parseFunction :: Parser HiValue
parseFunction = lexeme (choice
  [ chunk "div" >> pure HiFunDiv
  , chunk "mul" >> pure HiFunMul
  , chunk "add" >> pure HiFunAdd
  , chunk "sub" >> pure HiFunSub
  , chunk "and" >> pure HiFunAnd
  , chunk "or" >> pure HiFunOr
  , chunk "less-than" >> pure HiFunLessThan
  , chunk "greater-than" >> pure HiFunGreaterThan
  , chunk "equals" >> pure HiFunEquals
  , chunk "not-less-than" >> pure HiFunNotLessThan
  , chunk "not-greater-than" >> pure HiFunNotGreaterThan
  , chunk "not-equals" >> pure HiFunNotEquals
  , chunk "if" >> pure HiFunIf
  , chunk "not" >> pure HiFunNot
  , chunk "length" >> pure HiFunLength
  , chunk "to-upper" >> pure HiFunToUpper
  , chunk "to-lower" >> pure HiFunToLower
  , chunk "reverse" >> pure HiFunReverse
  , chunk "trim" >> pure HiFunTrim
  , chunk "list" >> pure HiFunList
  , chunk "range" >> pure HiFunRange
  , chunk "fold" >> pure HiFunFold
  , chunk "pack-bytes" >> pure HiFunPackBytes
  , chunk "unpack-bytes" >> pure HiFunUnpackBytes
  , chunk "encode-utf8" >> pure HiFunEncodeUtf8
  , chunk "decode-utf8" >> pure HiFunDecodeUtf8
  , chunk "zip" >> pure HiFunZip
  , chunk "unzip" >> pure HiFunUnzip
  , chunk "serialise" >> pure HiFunSerialise
  , chunk "deserialise" >> pure HiFunDeserialise
  , chunk "read" >> pure HiFunRead
  , chunk "write" >> pure HiFunWrite
  , chunk "mkdir" >> pure HiFunMkDir
  , chunk "cd" >> pure HiFunChDir
  , chunk "parse-time" >> pure HiFunParseTime
  , chunk "rand" >> pure HiFunRand
  , chunk "echo" >> pure HiFunEcho
  , chunk "count" >> pure HiFunCount
  , chunk "keys" >> pure HiFunKeys
  , chunk "values" >> pure HiFunValues
  , chunk "invert" >> pure HiFunInvert
  ]) <&> HiValueFunction

-- Parsing a number using the @scientific@ parser combinator.
parseNumber :: Parser HiValue
parseNumber = lexeme $ L.signed sc L.scientific <&> HiValueNumber . toRational

-- | Parsing a boolean value.
parseBool :: Parser HiValue
parseBool = lexeme $
  (chunk "false" >> pure (HiValueBool False)) <|>
  (chunk "true"  >> pure (HiValueBool True ))

-- | Parsing the null-value.
parseNull :: Parser HiValue
parseNull = lexeme $ chunk "null" >> pure HiValueNull

-- | Using the @stringLiteral@ parser combinator & wrapping it in the respective
-- @HiValue@ constructor.
parseString :: Parser HiValue
parseString = lexeme stringLiteral <&> HiValueString . T.pack

-- | Parsing the list of bytes.
parseBytes :: Parser HiValue
parseBytes = lexeme $ do
  chunk "[#"
  C.space
  args <- parseBytesArgs <|> return []
  chunk "#]"
  C.space
  return . HiValueBytes $ BS.pack args
  where
    parseBytesArgs :: Parser [Word8]
    parseBytesArgs = flip sepEndBy C.space1 $ do
      ch1 <- C.hexDigitChar
      ch2 <- C.hexDigitChar
      return $ strToWord8 [ch1, ch2]

-- | Parsing the dictionary.
parseDict :: Parser HiExpr
parseDict = lexeme $ do
  single '{'
  C.space
  args <- parseDictArgs <|> return []
  C.space
  single '}'
  C.space
  return $ HiExprDict args
  where
    parseDictArgs :: Parser [(HiExpr, HiExpr)]
    parseDictArgs = parseKV >>= parseRest . (: [])

    parseRest :: [(HiExpr, HiExpr)] -> Parser [(HiExpr, HiExpr)]
    parseRest acc = (do
        C.space
        single ','
        C.space
        hexpr <- parseKV
        parseRest (hexpr : acc)
      ) <|> return (reverse acc)

    parseKV :: Parser (HiExpr, HiExpr)
    parseKV = do
      key <- parseExprWithOperators
      C.space
      single ':'
      C.space
      val <- parseExprWithOperators
      return (key, val)

-- | Combination of certain @HiValue@ parser combinators.
parseValue :: Parser HiValue
parseValue = choice
  [ chunk "cwd" >> return (HiValueAction HiActionCwd)
  , chunk "now" >> return (HiValueAction HiActionNow)
  , parseBytes
  , parseFunction
  , parseNumber
  , parseBool
  , parseNull
  , parseString
  ]

-- | Parsing the comma-separated list of @HiExpr@s.
parseArgs :: Parser [HiExpr]
parseArgs = (parseExprWithOperators >>= parseRest . (: [])) <|> return []
  where
    parseRest :: [HiExpr] -> Parser [HiExpr]
    parseRest acc = (do
        C.space
        single ','
        C.space
        hexpr <- parseExprWithOperators
        parseRest (hexpr : acc)
      ) <|> return (reverse acc)

-- | Parsing the list.
parseList :: Parser HiExpr
parseList = lexeme $ do
  single '['
  C.space
  args <- parseArgs <|> return []
  C.space
  single ']'
  C.space
  return $ HiExprApply (HiExprValue (HiValueFunction HiFunList)) args

-- | Combination of certain @HiExpr@ parser combinators.
parseExpr :: Parser HiExpr
parseExpr = choice
  [ parens parseExprWithOperators
  , parseValue <&> HiExprValue
  , parseDict
  , parseList
  ] >>= parseFunctionApplicationFieldAccessorOrRun
  where
    parseFunctionApplicationFieldAccessorOrRun :: HiExpr -> Parser HiExpr
    parseFunctionApplicationFieldAccessorOrRun he = lexeme (do
        -- Parsing the function application of the form
        -- F(a1_1, ..., a1_n_1)(a2_1, ..., a2_n_2)...(am_1, ..., am_n_m)
        C.space
        single '('
        C.space
        args <- parseArgs
        C.space
        single ')'
        C.space
        parseFunctionApplicationFieldAccessorOrRun $ HiExprApply he args
      ) <|> lexeme (do
        -- Parsing the field accessor E.fld
        C.space
        single '.'
        fld <- (:) <$> satisfy isAlpha <*> many (choice
          [ satisfy isAlphaNum
          , single '-'
          , single '_'
          ])
        C.space
        parseFunctionApplicationFieldAccessorOrRun $
          HiExprApply he [HiExprValue . HiValueString $ T.pack fld]
      ) <|> lexeme (do
        -- Parsing of the runnable action identifier.
        C.space
        single '!'
        C.space
        parseFunctionApplicationFieldAccessorOrRun (HiExprRun he)
      ) <|> return he

-- | @parseExpr@ parser combinators merged with the operation table.
parseExprWithOperators :: Parser HiExpr
parseExprWithOperators = makeExprParser parseExpr opTable

-- | The main parsing function that takes a @String@ as an input & produces a @HiExpr@
-- with a posibility of failure.
parse :: String -> Either (ParseErrorBundle String Void) HiExpr
parse = runParser (C.space *> parseExprWithOperators <* C.space <* eof) ""
