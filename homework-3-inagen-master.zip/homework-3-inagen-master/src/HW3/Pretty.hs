module HW3.Pretty where

import           Data.Bool
import qualified Data.ByteString               as BS
import qualified Data.ByteString.Lazy          as BSL
import           Data.Foldable
import qualified Data.Map.Strict               as MS
import           Data.Ratio
import qualified Data.Text                     as T
import qualified Data.Text.Lazy                as TL
import           Data.Text.Lazy.Encoding
import           Numeric
import           Prettyprinter
import           Prettyprinter.Render.Terminal

import           HW3.Base
import           HW3.Util

-- | Prettify the supplied @HiValue@ argument.
prettyValue :: HiValue -> Doc AnsiStyle
prettyValue = \case
  HiValueNumber r ->
    let num = numerator r
        den = denominator r
    in if
      | den == 1 -> pretty num
      | isDivisibleBy2Or5 den -> pretty $
        showFFloat Nothing (fromIntegral num / fromIntegral den :: Double) ""
      | otherwise ->
        let (q, r) = quotRem num den
        in if | r == 0 -> pretty q
              | q == 0 -> pretty num <> "/" <> pretty den
              | otherwise ->
                pretty q <+> bool "-" "+" (r > 0) <+> pretty (abs r) <> "/" <> pretty den
  HiValueFunction f -> pretty $ show f
  HiValueBool b -> if b then pretty ("true" :: String) else pretty ("false" :: String)
  HiValueNull -> pretty ("null" :: String)
  HiValueString t -> pretty ("\"" :: String) <> pretty t <> pretty ("\"" :: String)
  HiValueList l -> prettyList (toList l) "[ " ", " " ]" "[]" prettyValue
  HiValueBytes y -> prettyList (BS.unpack y) "[# " " " " #]" "[# #]" $ pretty . word8ToStr
  HiValueAction he -> case he of
    HiActionRead s     -> pretty ("read(\"" ++ s ++ "\")" :: String)
    HiActionWrite s bs -> pretty ("write(\"" ++ s ++ "\", ") <>
      prettyValue (HiValueBytes bs) <>
      pretty (")" :: String)
    HiActionMkDir s    -> pretty ("mkdir(\"" ++ s ++ "\")" :: String)
    HiActionChDir s    -> pretty ("cd(\"" ++ s ++ "\")" :: String)
    HiActionCwd        -> pretty ("cwd" :: String)
    HiActionNow        -> pretty ("now" :: String)
    HiActionRand i1 i2 -> pretty ("rand(" ++ show i1 ++ ", " ++ show i2 ++ ")" :: String)
    HiActionEcho t     -> pretty ("echo(\"" <> t <> "\")" :: T.Text)
  HiValueTime u -> pretty $ show u
  HiValueDict m -> prettyList (MS.toList m) "{ " ", " " }" "{}" $ \(k, v) ->
    prettyValue k <> ": " <> prettyValue v
  where
    prettyList
      :: [a]                  -- ^ The primary list object
      -> String               -- ^ The opening encapsulator
      -> String               -- ^ The list item separator
      -> String               -- ^ The closing encapsulator
      -> String               -- ^ The empty list representation
      -> (a -> Doc AnsiStyle) -- ^ The element prettifier
      -> Doc AnsiStyle        -- ^ The resulting @Doc AnsiStyle@ object
    prettyList [] beg sep end emp fun = pretty emp
    prettyList l beg sep end emp fun  = pretty beg <> prettyList' l sep end fun
      where
        prettyList' [] sep end fun       = pretty end
        prettyList' [a] sep end fun      = fun a <> pretty end
        prettyList' (a : as) sep end fun = fun a <> go as

        go []       = pretty end
        go (a : as) = pretty sep <> fun a <> go as

    isDivisibleBy2Or5 :: Integer -> Bool
    isDivisibleBy2Or5 1 = True
    isDivisibleBy2Or5 a
      | a `rem` 5 == 0 = isDivisibleBy2Or5 $ a `quot` 5
      | even a = isDivisibleBy2Or5 $ a `quot` 2
      | otherwise = False
