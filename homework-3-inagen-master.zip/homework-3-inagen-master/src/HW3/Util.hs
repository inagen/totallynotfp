module HW3.Util where

import           Codec.Serialise
import           Control.Monad.Trans.Class
import           Data.Char
import           Data.Word
import           HW3.Base
import           System.Console.Haskeline

-- | Transform a hexadecimal character into its @Word8@ value.
hexLitToDecNum :: Char -> Word8
hexLitToDecNum ch
  | ch `elem` ['0' .. '9'] = fromIntegral (ord ch) - 48
  | ch `elem` ['A' .. 'F'] = fromIntegral (ord ch) - 65 + 10
  | ch `elem` ['a' .. 'f'] = fromIntegral (ord ch) - 97 + 10
  | otherwise = error "Character does not belong to the hexadecimal digit alphabet."

-- | Transform a @Word8@ representation of a hexadecimal character to the character itself.
decNumToHexLit :: Word8 -> Char
decNumToHexLit w8
  | w8 < 10 = chr $ fromIntegral (w8 + 48)
  | otherwise = chr $ fromIntegral (w8 - 10 + 97)

-- | Transform a two-letter hexadecimal string into its decimal form.
strToWord8 :: String -> Word8
strToWord8 [a, b] = hexLitToDecNum a * 16 + hexLitToDecNum b
strToWord8 _      =
  error "The string representation of the byte should contain exactly 2 characters."

-- | Transform a decimal representation of a two-letter hexadecimal string into that
-- string itself.
word8ToStr :: Word8 -> String
word8ToStr w8 = map decNumToHexLit [w8 `quot` 16, w8 `rem` 16]

instance HiMonad m => HiMonad (InputT m) where
  runAction = lift . runAction
