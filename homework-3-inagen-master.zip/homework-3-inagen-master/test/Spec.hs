import qualified Data.ByteString       as BS
import           Data.Either
import           Data.Functor.Identity
import           Data.Ratio
import           Data.Semigroup
import qualified Data.Sequence         as Seq
import           Test.Hspec

import           HW3.Action
import           HW3.Base
import           HW3.Evaluator
import           HW3.Parser
import           HW3.Pretty

check :: String -> HiValue -> Spec
check s hivalue = it (s ++ " should evaluate to " ++ show (prettyValue hivalue)) $ do
  let p = fromRight (error $ "Parsing of " ++ s ++ " failed.") $ parse s
  eval'd <- eval p >>= either (error . show) return
  eval'd `shouldBe` hivalue

check' :: String -> String -> Spec
check' s s' = it (s ++ " should evaluate to " ++ s') $ do
  let p = fromRight (error $ "Parsing of " ++ s ++ " failed.") $ parse s
      p' = fromRight (error $ "Parsing of " ++ s ++ " failed.") $ parse s'
  eval'd <- eval p >>= either (error . show) return
  eval'd' <- eval p' >>= either (error . show) return
  eval'd `shouldBe` eval'd'

checkWithError :: String -> Either HiError HiValue -> Spec
checkWithError s e = it (s ++ " should evaluate to " ++ show e) $ do
  let p = fromRight (error $ "Parsing of " ++ s ++ " failed.") $ parse s
  eval'd <- eval p
  eval'd `shouldBe` e

checkParsing :: String -> HiExpr -> Spec
checkParsing s hiexpr = it (s ++ " should parse to " ++ show hiexpr) $ do
  let p = fromRight (error $ "Parsing of " ++ s ++ " failed.") $ parse s
  p `shouldBe` hiexpr

main :: IO ()
main = hspec $ do
  describe "Task 1: Numbers and arithmetic" $ do
    "100" `check` HiValueNumber 100
    "-15" `check` HiValueNumber (-15)
    "add(100, -15)" `check` HiValueNumber 85
    "add(3, div(14, 100))" `check` HiValueNumber 3.14
    "div(10, 3)" `check` HiValueNumber (10 % 3)
    "sub(mul(201, 11), 0.33)" `check` HiValueNumber 2210.67
  describe "Task 2: Booleans and comparison" $ do
    "false" `check` HiValueBool False
    "equals(add(2, 2), 4)" `check` HiValueBool True
    "less-than(mul(999, 99), 10000)" `check` HiValueBool False
    "less-than(false, -123)" `check` HiValueBool True
    "if(greater-than(div(2, 5), div(3, 7)), 1, -1)" `check` HiValueNumber (-1)
    "and(less-than(0, 1), less-than(1, 0))" `check` HiValueBool False
    "if(true, add, mul)" `check` HiValueFunction HiFunAdd
    "if(true, add, mul)(10, 10)" `check` HiValueNumber 20
    "if(false, add, mul)(10, 10)" `check` HiValueNumber 100
    "equals(add, add)" `check` HiValueBool True
    "equals(add, mul)" `check` HiValueBool False
  describe "Task 3: Operators" $ do
    "2 + 2" `check` HiValueNumber 4
    "2 + 2 * 3" `check` HiValueNumber 8
    "(2 + 2) * 3" `check` HiValueNumber 12
    "2 + 2 * 3 == (2 + 2) * 3" `check` HiValueBool False
    "10 == 2*5 && 143 == 11*13" `check` HiValueBool True
  describe "Task 4: Strings and slices" $ do
    "to-upper(\"Hello World\")" `check` HiValueString "HELLO WORLD"
    "to-lower(\"Hello World\")" `check` HiValueString "hello world"
    "reverse(\"Hello World\")" `check` HiValueString "dlroW olleH"
    "trim(\"    Hello World \")" `check` HiValueString "Hello World"
    "to-upper(\"what a nice language\")(7, 11)" `check` HiValueString "NICE"
    "\"Hello\" == \"World\"" `check` HiValueBool False
    "length(\"Hello\" + \"World\")" `check` HiValueNumber 10
    "length(\"hehe\" * 5) / 3" `check` HiValueNumber (20 % 3)
    "\"Hello World\"(0)" `check` HiValueString "H"
    "\"Hello World\"(7)" `check` HiValueString "o"
    "\"Hello World\"(-1)" `check` HiValueNull
    "\"Hello World\"(11)" `check` HiValueNull
    "\"Hello World\"(0, 5)" `check` HiValueString "Hello"
    "\"Hello World\"(2, 4)" `check` HiValueString "ll"
    "\"Hello World\"(0, -4)" `check` HiValueString "Hello W"
    "\"Hello World\"(-4, -1)" `check` HiValueString "orl"
    "\"Hello World\"(2, null)" `check` HiValueString "llo World"
    "\"Hello World\"(null, 5)" `check` HiValueString "Hello"
  describe "Task 5: Lists and folds" $ do
    "list(1, 2, 3)" `check` HiValueList (Seq.fromList $ fmap HiValueNumber [1, 2, 3])
    "range(5, 10.3)" `check` HiValueList (Seq.fromList $ fmap HiValueNumber [5 .. 10])
    "fold(add, [11, 22, 33])" `check` HiValueNumber 66
    "fold(sub, [11, 22, 33])" `check` HiValueNumber (-44)
    "fold(mul, [11, 22, 33])" `check` HiValueNumber 7986
    "fold(div, [11, 22, 33])" `check` HiValueNumber (1 % 66)
    "length([1, true, \"Hello\"])" `check` HiValueNumber 3
    "reverse([1, true, \"Hello\"])" `check` HiValueList (Seq.fromList
      [HiValueString "Hello", HiValueBool True, HiValueNumber 1])
    "[1, 2] + [3, 4, 5]" `check` HiValueList (Seq.fromList $ fmap HiValueNumber [1 .. 5])
    "[0, \"x\"] * 3" `check` HiValueList (Seq.fromList $ stimes 3 [HiValueNumber 0, HiValueString "x"])
    "list(1, 2, 3, 4, 5)" `check` HiValueList (Seq.fromList $ fmap HiValueNumber [1 .. 5])
    "fold(add, [2, 5] * 3)" `check` HiValueNumber 21
    "fold(mul, range(1, 10))" `check` HiValueNumber 3628800
    "[0, true, false, \"hello\", \"world\"](2, 4)" `check` HiValueList (Seq.fromList
      [HiValueBool False, HiValueString "hello"])
    "reverse(range(0.5, 70/8))" `check` HiValueList (Seq.fromList $ fmap HiValueNumber
      [8.5, 7.5 .. 0.5])
    "[false, null, 6](0)" `check'` "false"
    "[false, null, 6](2)" `check'` "6"
    "[false, null, 6](-1)" `check` HiValueNull
    "[false, null, 6](11)" `check` HiValueNull
    "[false, null, 6](0, 2)" `check'` "[false, null]"
    "[false, null, 6](1, 3)" `check'` "[null, 6]"
    "[false, null, 6](0, -2)" `check'` "[false]"
    "[false, null, 6](-2, -1)" `check'` "[null]"
    "[false, null, 6](2, null)" `check'` "[6]"
    "[false, null, 6](null, 3)" `check'` "[false, null, 6]"
  describe "Task 6: Bytes and serialisation" $ do
    "pack-bytes([ 3, 255, 158, 32 ])" `check` HiValueBytes (BS.pack [3, 255, 158, 32])
    "unpack-bytes([# 10 20 30 #])" `check`
      HiValueList (Seq.fromList $ fmap HiValueNumber [16, 32, 48])
    "encode-utf8(\"Hello!\")" `check'` "[# 48 65 6c 6c 6f 21 #]"
    "decode-utf8([# 48 65 6c 6c 6f #])" `check` HiValueString "Hello"
    "decode-utf8([# c3 28 #])" `check` HiValueNull
    "[# 00 ff #] + [# 01 e3 #]" `check'` "[# 00 ff 01 e3 #]"
    "[# 00 ff #] * 3" `check'` "[# 00 ff 00 ff 00 ff #]"
    "deserialise(serialise(-0.5))" `check` HiValueNumber (-0.5)
    "deserialise(serialise(deserialise))" `check` HiValueFunction HiFunDeserialise
    "deserialise(serialise(true))" `check` HiValueBool True
    "deserialise(serialise(null))" `check` HiValueNull
    "deserialise(serialise(\"serialise_me^daddy\"))" `check` HiValueString "serialise_me^daddy"
    "deserialise(serialise([]))" `check` HiValueList (Seq.fromList [])
    "deserialise(serialise([# 20 30 ff #]))" `check` HiValueBytes (BS.pack [32, 48, 255])
    "pack-bytes(range(30, 40))" `check'` "[# 1e 1f 20 21 22 23 24 25 26 27 28 #]"
    "zip(encode-utf8(\"Hello, World!\" * 1000))" `check'`
      "[# 78 da ed c7 31 0d 00 20 0c 00 30 2b f0 23 64 0e 30 00 df 92 25 f3 7f a0 82 af \
         \fd 1a 37 b3 d6 d8 d5 79 66 88 88 88 88 88 88 88 88 88 88 88 88 88 88 88 88 88 \
         \88 88 88 88 88 88 88 88 fc c9 03 ca 0f 3b 28 #]"
    "decode-utf8([# 68 69 #] * 5)" `check` HiValueString "hihihihihi"
    "unzip([# 78 da 63 64 62 06 00 00 0d 00 07 #])" `check'` "[# 01 02 03 #]"
    "[# 00 10 20 30 40 50 #](0)" `check'` "0"
    "[# 00 10 20 30 40 50 #](5)" `check'` "80"
    "[# 00 10 20 30 40 50 #](-1)" `check` HiValueNull
    "[# 00 10 20 30 40 50 #](11)" `check` HiValueNull
    "[# 00 10 20 30 40 50 #](0, 4)" `check'` "[# 00 10 20 30 #]"
    "[# 00 10 20 30 40 50 #](2, 6)" `check'` "[# 20 30 40 50 #]"
    "[# 00 10 20 30 40 50 #](0, -4)" `check'` "[# 00 10 #]"
    "[# 00 10 20 30 40 50 #](-5, -1)" `check'` "[# 10 20 30 40 #]"
    "[# 00 10 20 30 40 50 #](2, null)" `check'` "[# 20 30 40 50 #]"
    "[# 00 10 20 30 40 50 #](null, 3)" `check'` "[# 00 10 20 #]"
  describe "Task 8: Date and time" $ do
    "parse-time(\"2021-12-15 00:00:00 UTC\") + 1000" `check'`
      "parse-time(\"2021-12-15 00:16:40 UTC\")"
    "parse-time(\"2021-12-15 00:16:40\")" `check` HiValueNull
    "parse-time(\"2021-12-15 00:37:51.000890793 UTC\") - \
      \parse-time(\"2021-12-15 00:37:47.649047038 UTC\")" `check'`
        "3.351843755"
    "parse-time(\"2021-01-01 00:00:00 UTC\") + 365 * 24 * 60 * 60" `check'`
      "parse-time(\"2022-01-01 00:00:00 UTC\")"
  describe "Task 10: Short-circuit evaluation" $ do
    "\"Hello\"(0) || \"Z\"" `check'` "\"H\""
    "\"Hello\"(99) || \"Z\"" `check'` "\"Z\""
    "true || echo(\"Don't do this\")!" `check'` "true"
    "false && echo(\"Don't do this\")!" `check'` "false"
    "null && echo(\"Don't do this\")!" `check'` "null"
  describe "Task 11: Dictionaries" $ do
    "{ \"width\": 120, \"height\": 80 }(\"width\")" `check'` "120"
    "{ \"width\": 120, \"height\": 80 }(\"length\")" `check` HiValueNull
    "keys({ \"width\": 120, \"height\": 80 })" `check'` "[\"height\", \"width\"]"
    "values({ \"width\": 80, \"height\": 120 })" `check'` "[120, 80]"
    "count(\"XXXOX\")" `check'` "{ \"O\": 1, \"X\": 4 }"
    "count([# 58 58 58 4f 58 #])" `check'` "{ 79: 1, 88: 4 }"
    "count([true, true, false, true])" `check'` "{ false: 1, true: 3 }"
    "invert({ \"x\": 1, \"y\" : 2, \"z\": 1 })" `check'` "{ 1: [ \"z\", \"x\" ], 2: [\"y\"] }"
    "count(\"Hello World\").o" `check` HiValueNumber 2
    "invert(count(\"big blue bag\"))" `check'`
      "{ 1: [ \"u\", \"l\", \"i\", \"e\", \"a\" ], 2: [ \"g\", \" \" ], 3: [\"b\"] }"
    "fold(add, values(count(\"Hello, World!\")))" `check` HiValueNumber 13
  describe "Grand Finale!!!" $ do
    "(div(1))(10)" `checkParsing`
      HiExprApply (
        HiExprApply (HiExprValue (HiValueFunction HiFunDiv)) [HiExprValue (HiValueNumber (1 % 1))]
      ) [HiExprValue (HiValueNumber (10 % 1))]
    "if(true, 1, 1 / 0)" `check` HiValueNumber 1
    "{}.hello-world" `checkParsing`
      HiExprApply (HiExprDict []) [HiExprValue (HiValueString "hello-world")]
    "\"abc\"(1, 2.2)" `checkWithError` Left HiErrorInvalidArgument
    "reverse.to-upper.hello" `checkParsing`
      HiExprApply (
        HiExprApply (HiExprValue (HiValueFunction HiFunReverse))
          [HiExprValue (HiValueString "to-upper")]
      ) [HiExprValue (HiValueString "hello")]
    "[]" `check` HiValueList (Seq.fromList [])
    "list()" `check` HiValueList (Seq.fromList [])
    "[# #]" `check` HiValueBytes (BS.pack [])
    "pack-bytes([])" `check` HiValueBytes (BS.pack [])
    "if(true, { \"width\" : 1 }, 1+1).width" `check` HiValueNumber 1
    "zip.add(1, 1)" `checkParsing`
      HiExprApply (
        HiExprApply (HiExprValue (HiValueFunction HiFunZip)) [HiExprValue (HiValueString "add")]
      ) [HiExprValue (HiValueNumber (1 % 1)),HiExprValue (HiValueNumber (1 % 1))]
    "(div)(1, 2)" `check` HiValueNumber 0.5
